import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import model_selection, metrics
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import LabelEncoder

from app import IDcol

output_dir = "C:\\Users\\PRAVEEN\\Dmart Sales Analysis\\data"
os.makedirs(output_dir, exist_ok=True)

train = pd.read_csv("C:\\Users\\PRAVEEN\\Dmart Sales Analysis\\train (1).csv")
test = pd.read_csv("C:\\Users\\PRAVEEN\\Dmart Sales Analysis\\test (1).csv")

# Data visualization
plt.figure(figsize=(12, 7))
sns.histplot(train.Item_Outlet_Sales, bins=25, kde=True)
plt.ticklabel_format(style='plain', axis='x', scilimits=(0, 1))
plt.xlabel("Item_Outlet_Sales")
plt.ylabel("Number of Sales")
plt.title("Item_Outlet_Sales Distribution")
plt.show()

plt.figure()
sns.countplot(x='Item_Fat_Content', data=train)
plt.show()

plt.figure()
sns.countplot(x='Item_Type', data=train)
plt.xticks(rotation=90)
plt.show()

plt.figure()
sns.countplot(x='Outlet_Size', data=train)
plt.show()

plt.figure()
sns.countplot(x='Outlet_Location_Type', data=train)
plt.show()

plt.figure()
sns.countplot(x='Outlet_Type', data=train)
plt.xticks(rotation=90)
plt.show()

# Data preprocessing and model training
train['source'] = 'train'
test['source'] = 'test'

data = pd.concat([train, test], ignore_index=True)

# Functions for data preprocessing (imputations, transformations, etc.)

# Model fitting function
def modelfit(alg, dtrain, dtest, predictors, target, IDcol, filename):
    alg.fit(dtrain[predictors], dtrain[target])
    dtrain_predictions = alg.predict(dtrain[predictors])
    Sq_train = (dtrain[target]) ** 2

    cv_score = model_selection.cross_val_score(alg, dtrain[predictors], Sq_train, cv=20, scoring='neg_mean_squared_error')
    cv_score = np.sqrt(np.abs(cv_score))

    print("\nModel Report")
    print(f"RMSE : {np.sqrt(metrics.mean_squared_error(Sq_train.values, dtrain_predictions)):.4g}")
    print(f"CV Score : Mean - {np.mean(cv_score):.4g} | Std - {np.std(cv_score):.4g} | Min - {np.min(cv_score):.4g} | Max - {np.max(cv_score):.4g}")

    dtest[target] = alg.predict(dtest[predictors])
    IDcol.append(target)
    submission = pd.DataFrame({x: dtest[x] for x in IDcol})
    submission.to_csv(filename, index=False)

# Model training and evaluation
predictors = train.columns.drop(['Item_Outlet_Sales', 'Item_Identifier', 'Outlet_Identifier'])

# Train models
LR = LinearRegression()
modelfit(LR, train, test, predictors, 'Item_Outlet_Sales', IDcol, os.path.join(output_dir, 'LR.csv'))

DT = DecisionTreeRegressor(max_depth=15, min_samples_leaf=100)
modelfit(DT, train, test, predictors, 'Item_Outlet_Sales', IDcol, os.path.join(output_dir, 'DT.csv'))

RF = DecisionTreeRegressor(max_depth=8, min_samples_leaf=150)
modelfit(RF, train, test, predictors, 'Item_Outlet_Sales', IDcol, os.path.join(output_dir, 'RF.csv'))
