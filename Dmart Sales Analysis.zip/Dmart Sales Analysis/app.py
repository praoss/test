import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import streamlit as st
from sklearn import model_selection, metrics
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings("ignore")


output_dir = "C:\\Users\\PRAVEEN\\Dmart Sales Analysis\\data"
os.makedirs(output_dir, exist_ok=True)

try:
    train = pd.read_csv("C:\\Users\\PRAVEEN\\Dmart Sales Analysis\\train (1).csv")
    test = pd.read_csv("C:\\Users\\PRAVEEN\\Dmart Sales Analysis\\test (1).csv")
except FileNotFoundError as e:
    st.error(f"Error loading data: {e}")
    st.stop()


st.title('BigMart Sales Prediction')
st.header('Data Visualization')
st.subheader('Item Outlet Sales Distribution')
fig, ax = plt.subplots(figsize=(12, 7))
sns.histplot(train.Item_Outlet_Sales, bins=25, kde=True, ax=ax)
plt.ticklabel_format(style='plain', axis='x', scilimits=(0, 1))
plt.xlabel("Item_Outlet_Sales")
plt.ylabel("Number of Sales")
plt.title("Item_Outlet_Sales Distribution")
st.pyplot(fig)


st.subheader('Item Fat Content Distribution')
fig, ax = plt.subplots()
sns.countplot(x='Item_Fat_Content', data=train, ax=ax)
st.pyplot(fig)


st.subheader('Item Type Distribution')
fig, ax = plt.subplots()
sns.countplot(x='Item_Type', data=train, ax=ax)
plt.xticks(rotation=90)
st.pyplot(fig)


st.subheader('Outlet Size Distribution')
fig, ax = plt.subplots()
sns.countplot(x='Outlet_Size', data=train, ax=ax)
st.pyplot(fig)

st.subheader('Outlet Location Type Distribution')
fig, ax = plt.subplots()
sns.countplot(x='Outlet_Location_Type', data=train, ax=ax)
st.pyplot(fig)


st.subheader('Outlet Type Distribution')
fig, ax = plt.subplots()
sns.countplot(x='Outlet_Type', data=train, ax=ax)
plt.xticks(rotation=90)
st.pyplot(fig)


train['source'] = 'train'
test['source'] = 'test'

data = pd.concat([train, test], ignore_index=True)
st.write(f"Train shape: {train.shape}, Test shape: {test.shape}, Combined shape: {data.shape}")

item_avg_weight = data.pivot_table(values='Item_Weight', index='Item_Identifier')

def impute_weight(cols):
    Weight = cols[0]
    Identifier = cols[1]
    if pd.isnull(Weight):
        return item_avg_weight['Item_Weight'][item_avg_weight.index == Identifier]
    else:
        return Weight

data['Item_Weight'] = data[['Item_Weight', 'Item_Identifier']].apply(impute_weight, axis=1).astype(float)

outlet_size_mode = data.pivot_table(values='Outlet_Size', columns='Outlet_Type', aggfunc=lambda x: x.mode())

def impute_size_mode(cols):
    Size = cols[0]
    Type = cols[1]
    if pd.isnull(Size):
        return outlet_size_mode.loc['Outlet_Size'][outlet_size_mode.columns == Type][0]
    else:
        return Size

data['Outlet_Size'] = data[['Outlet_Size', 'Outlet_Type']].apply(impute_size_mode, axis=1)

visibility_item_avg = data.pivot_table(values='Item_Visibility', index='Item_Identifier')

def impute_visibility_mean(cols):
    visibility = cols[0]
    item = cols[1]
    if visibility == 0:
        return visibility_item_avg['Item_Visibility'][visibility_item_avg.index == item]
    else:
        return visibility

data['Item_Visibility'] = data[['Item_Visibility', 'Item_Identifier']].apply(impute_visibility_mean, axis=1).astype(float)

data['Outlet_Years'] = 2013 - data['Outlet_Establishment_Year']

data['Item_Type_Combined'] = data['Item_Identifier'].apply(lambda x: x[0:2])
data['Item_Type_Combined'] = data['Item_Type_Combined'].map({'FD': 'Food', 'NC': 'Non-Consumable', 'DR': 'Drinks'})

data['Item_Fat_Content'] = data['Item_Fat_Content'].replace({'LF': 'Low Fat', 'reg': 'Regular', 'low fat': 'Low Fat'})
data.loc[data['Item_Type_Combined'] == "Non-Consumable", 'Item_Fat_Content'] = "Non-Edible"

def func(x):
    return x['Item_Visibility'] / visibility_item_avg['Item_Visibility'][visibility_item_avg.index == x['Item_Identifier']][0]

data['Item_Visibility_MeanRatio'] = data.apply(func, axis=1).astype(float)

le = LabelEncoder()
data['Outlet'] = le.fit_transform(data['Outlet_Identifier'])

var_mod = ['Item_Fat_Content', 'Outlet_Location_Type', 'Outlet_Size', 'Item_Type_Combined', 'Outlet_Type', 'Outlet']

for i in var_mod:
    data[i] = le.fit_transform(data[i])

data.drop(['Item_Type', 'Outlet_Establishment_Year'], axis=1, inplace=True)

train = data.loc[data['source'] == "train"]
test = data.loc[data['source'] == "test"]

test.drop(['Item_Outlet_Sales', 'source'], axis=1, inplace=True)
train.drop(['source'], axis=1, inplace=True)

train.to_csv(os.path.join(output_dir, "train_modified.csv"), index=False)
test.to_csv(os.path.join(output_dir, "test_modified.csv"), index=False)

train_df = pd.read_csv(os.path.join(output_dir, 'train_modified.csv'))
test_df = pd.read_csv(os.path.join(output_dir, 'test_modified.csv'))

target = 'Item_Outlet_Sales'
IDcol = ['Item_Identifier', 'Outlet_Identifier']

def modelfit(alg, dtrain, dtest, predictors, target, IDcol, filename):
    alg.fit(dtrain[predictors], dtrain[target])
    dtrain_predictions = alg.predict(dtrain[predictors])
    Sq_train = (dtrain[target])**2

    cv_score = model_selection.cross_val_score(alg, dtrain[predictors], Sq_train, cv=20, scoring='neg_mean_squared_error')
    cv_score = np.sqrt(np.abs(cv_score))

    st.write("\nModel Report")
    st.write(f"RMSE : {np.sqrt(metrics.mean_squared_error(Sq_train.values, dtrain_predictions)):.4g}")
    st.write(f"CV Score : Mean - {np.mean(cv_score):.4g} | Std - {np.std(cv_score):.4g} | Min - {np.min(cv_score):.4g} | Max - {np.max(cv_score):.4g}")

    dtest[target] = alg.predict(dtest[predictors])
    IDcol.append(target)
    submission = pd.DataFrame({x: dtest[x] for x in IDcol})
    submission.to_csv(filename, index=False)

predictors = train_df.columns.drop(['Item_Outlet_Sales', 'Item_Identifier', 'Outlet_Identifier'])

st.header('Model Training and Evaluation')


if st.button('Train Linear Regression Model'):
    LR = LinearRegression()
    modelfit(LR, train_df, test_df, predictors, target, IDcol, os.path.join(output_dir, 'LR.csv'))


if st.button('Train Decision Tree Model'):
    DT = DecisionTreeRegressor(max_depth=15, min_samples_leaf=100)
    modelfit(DT, train_df, test_df, predictors, target, IDcol, os.path.join(output_dir, "DT.csv"))


if st.button('Train Random Forest Model'):
    RF = DecisionTreeRegressor(max_depth=8, min_samples_leaf=150)
    modelfit(RF, train_df, test_df, predictors, target, IDcol, os.path.join(output_dir, "RF.csv"))
